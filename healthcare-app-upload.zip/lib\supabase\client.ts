// Placeholder for Supabase client - not used in demo mode
export function createClient() {
  return null
}
