// Placeholder for Supabase server client - not used in demo mode
export async function createClient() {
  return null
}
